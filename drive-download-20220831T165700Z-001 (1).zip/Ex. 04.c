#include <stdio.h>
#include "vetlib.h"

int main(){
	int i,qtd;
	printf("Informe a quantidade de elementos do vetor:");
	scanf("%d",&qtd);
	int vet[qtd];
	leiaVetor(vet,qtd); // fim leitura do vetor
	
	imparVet(vet,qtd);
	
	return 0;
	
} 
