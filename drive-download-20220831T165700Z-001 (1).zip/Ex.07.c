#include <stdio.h>
#include <stdlib.h>
#include "bibliotecastrings.h"

void main(){
	
	int n;
	
	printf("Insira a qtd de elementos a serem multiplicados: ");
	scanf("%d", &n);
	int vet1[n], vet2[n], vetres[n];
	
	geraVetor(vet1, n, 20);
	geraVetor(vet2, n, 20);
	
	for(int i = 0; i < n; i++){
		vetres[i] = vet1[i] * vet2[i];
	}
	
	printf("Elementos do vetor 1: ");
	printaVetor(vet1, n);
	printf("\n\nElementos do vetor 2: ");
	printaVetor(vet2, n);
	printf("\n\nElementos multiplicados: ");
	printaVetor(vetres, n);
	
}
