#include <stdio.h>
#include "bibliotecastrings.h"

void main(){
	
	int numero, face = 0;
	
	
	printf("Insira o n� de lancamentos do dado: ");
	scanf("%d", &numero);
	int lanc[num];
	
	geraVetor(lanc, numero, 6);
	printaVetor(lanc, numero);
	
	for(int i = 1; i <= 6; i++){
		for(int j = 0; j < numero; j++){
			if(lanc[j] == i){
				face++;
			}
		}
		printf("\nO lado [%d] aparece %d vez(es).\n", i, face);
		face = 0;
	}

}
